package domain

case class User(id: Long, username: String, password: String)
