package models

case class Pokemon(id: Int, name: String, height: Int, weight: Int, types: Seq[String])
