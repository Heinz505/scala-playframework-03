package models.domain

import java.util.UUID

case class Author(id: UUID, firstName: String, lastName: String)
